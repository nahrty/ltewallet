<TS language="it_IT" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Click destro per modificare indirizzo o etichetta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crea un nuovo indirizzo</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>nuovo</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>copia l'indirizzo selezionato correntemente nella clipboard di sistema</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>copia</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>chiudi </translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Cancella l'indirizzo attualmente selezionato dalla lista.</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Esportare i dati nella scheda corrente in un file</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Scegli l'indirizzo a cui inviare denaro</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>Scegli</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Invia passphrase</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nuova passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Ripeti nuova passphrase</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Attenzione: Il tasto blocco delle maiuscole è attivo!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP/Netmask</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>bannato fino </translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>&amp;Transactions</source>
        <translation>Transazioni</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>ModalOverlay</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    </context>
</TS>